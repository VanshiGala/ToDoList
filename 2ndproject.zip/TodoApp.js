// TodoApp.js
import React from 'react';

const TodoApp = () => {
  return (
    <div className='todo'>
      <h1>Welcome to your Todo App!</h1>
    </div>
  );
};

export default TodoApp;
